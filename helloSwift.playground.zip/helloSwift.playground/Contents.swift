import UIKit
import MapKit


/* Warming Up

 
 var str/* 인라인주석 */ = "Hello, playground"
//싱글라인주석
 /*
 멀티라인주석
 */

 /*
Token, Expressions, Statements
 
 Tokens : 더이상 쪼갤수 없는 단위(원자)
Expressions: 표현식. 토큰이 모여 표현식을 이룸 ex. 불리언 표현식
Statements : 문장,구문 표현식이 모여 구문을 이룸. 끝에 ; 생략해도 됨 ex. if,for,switch ...
 */

 /*
 Literal, identifier, Keyword
 
 Literal: 코드내에서 의미가 변하지않고 있는그대로 사용되는 값 ex.숫자리터럴 let x = 7, let x = 5 + 7, let x2 = x > 7 :x2는 상수이름이므로 literal 아님
 Identifier: 식별자(이름). ex. let x = 7 :x, 숫자로는 시작할 수 없음, _가능, 대소문자 구별해야됨
 KeyWord: 예약어(예약된단어): let x = 7 :let, ex. let var class..., 키워드는 식별자이름으로 사용할 수 없음 ex. let let = 7 안됨! 포함은 가능
 */

 /*
 Compile, Link, Run
 
 Compiler: 소스코드를 0,1(바이너리코드)로 변환해줌, Xcode에 내장되어있음. 오류를 Warning(실행되나 논리적문제 있을 수 있음, 노란삼각형)과 Error(실행불가, 빨간원)로 구분함
 Link: 바이너리코드와 프레임워크를 연결해주는 과정, Xcode에 내장(command R)    Compile + Link = Build 하면 실행파일이 생성가능
 
 여기까지가 CompileTime
 
 DebugMode : 디버그할수있는 정보가 포함된 실행파일. 파일크기가 상대적으로 큼, 대신 오류를 쉽게 찾을 수 있음, 앱스토어 업로드 불가(만들때 사용)
 Release Mode: 디버그정보 포함X,상대적으로 파일크기작고, 최적화되어 실행속도도 빠름 앱스토어 업로드 가능(업로드할때 사용)
 
 여기까지가 RunTime
 
 */

 /*
Special Characters 다양한 특수문자
 
 !: Exclamation Mark - 논리를 부정(참을 거짓으로,거짓을 참으로),옵셔널에서는 저장된 값을 강제로 꺼낼때 사용
 ~: Tilde - 비트연산자에서 사용
 `: Back tic - 키워드를 아이덴티파이어로 바꾸는 문법에서 사용
 @: At Symbol - 코드 자체에 특성을 지정하는 용도
 #: Sharp,Pound,Hashtag - 스위프트가 제공하는 특별한 명령어가 시작할때 붙임
 $: Dollar Sign - 클로저에서 파라미터 이름을 대체할 때 사용
 %: Percent Sign - 나머지를 구할때 사용
 ^: Caret - 비트연산에서 사용
 &: Ampersand - 주로 메모리주소를 얻거나 참조를 전달할 때 사용
 *: Asterisk - 곱하기연산
 (): Parentheses: 함수를 호출할 때, 계산의 순서를 지정할 때
 -: Minus Sign,Hyphen - 빼기
 _: underscore - 와일드카드패턴을 구현할때 자주사용
 =: Equal Sign - 변수나 상수의 값을 저장할 때, ==하면 두개의 값을 비교함
 []: Square Bracket - 컬렉션에 저장된 값에 접근할 때 사용  *
 {}: Curly Bracket, Brace - 코드블록의 범위를 지정할 때  *
 \: Back slash - 스트링 인터폴레이스문법 등
 |: Vertical Bar/ Pipe - 주로 논리연산이나 비트연산에서 사용
 ;: SemiColon - 문장의 마침표 역할. 두개의문장을 한줄에 사용하는 경우 아니면 사용하는경우는 드뭄. but 옵젝트C와 연계할때는 사용해야함
 :: Colon - 자료형을 지정할 때, 딕셔너리에서 키와값을 구분할때도 사용
 ,: comma - 함수로 전달되는 값이나 배열에 저장할 값을 나열할 때
 .: Period - 메소드를 호출하거나 속성에 접근
 <>: Angle Bracket - 크기를 비교하는 연산자, 제네릭에서는 형식파라미터를 지정할 때  *
 /: Slash - 주로 경로를 지정하는데 사용
 ?: Question Mark - 주로 옵셔널에서 사용
 */

 /*
 FirstClassCitizen 암기
 
 1. Can be stored in variables and data structures 상수와 변수에 저장할 수 있다.
 2. can be passed as a parameter to a function 파라미터로 전달할 수 있다.
 3. can ba returned as the result of a function 함수에서 리턴할 수 있다.
 */

*/


/* Working with Variables 변수와 상수
 
 
 /*
 Variables and Constants
 
 
 
 */
 
 */
